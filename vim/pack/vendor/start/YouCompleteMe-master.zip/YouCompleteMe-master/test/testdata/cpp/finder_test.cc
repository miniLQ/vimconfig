#include <stdio.h>

struct Test
{
  int x_this_is_a_thing; int x_that_is_a_thing;
};

int main() {
  Test t;

}

